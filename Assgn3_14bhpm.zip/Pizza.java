import java.io.Serializable;

/**
 * This is the Pizza class for Assignment 3
 * It describes a regular pizza with four attributes: 
 * - size - cheese - ham - pepperoni -
 * For the methods, only the mutators, costForSize and numOfTopToStr are private
 * 
 * @author Beltan Michel - 10169162 - 14bhpm
 * @version 1.0
 */ 

public class Pizza implements Serializable{
	
	/* Object Attributes */
	private static final long serialVersionUID = 1; //This class was not created using Eclipse
	private String size;
	private int cheese;
	private int ham;
	private Integer pepperoni;
	
	/**
	 * This is the regular constructor for Pizza
	 * It simply calls the setAttribute methods for each attribute.
	 * 
	 * @param size The desired size of the pizza
	 * @param cheese The portion of cheese you want on your pizza
	 * @param ham The portion of ham you want on your pizza
	 * @param pepperoni The portion of pepperoni you want on your pizza
	 */ 
	public Pizza(String size, int cheese, int ham, int pepperoni) throws IllegalPizza{
		
		setSize(size);
		setCheese(cheese);
		setHam(ham);
		setPepperoni(pepperoni);
		
	}
	
	/**
	 * This is the second constructor for Pizza with only size supplied
	 * Just as the other constructor, it calls the setAttribute methods
	 * for each attribute, using the defaults for cheese, ham and pepperoni
	 * 
	 * @param size The desired size of the pizza
	 */ 
	public Pizza(String size) throws IllegalPizza{
		
		setSize(size);
		setCheese(1); //The default for cheese is 1
		setHam(0); //The default for ham is 0
		setPepperoni(1); //The default for pepperoni is 1
		
	}
	
	/* This method will set the size to the attribute */
	private void setSize(String size) throws IllegalPizza {
		
		if ((size.equals("small")) || (size.equals("medium")) || (size.equals("large"))){
			this.size = size;
		} else {
			throw new IllegalPizza("The size you entered is invalid");
		}
		
	}
	
	/* This method will set the number of cheese to the attribute */
	private void setCheese(int cheese) throws IllegalPizza {
		
		int minCheese = 1; //The minimum legal value for cheese
		int maxCheese = 3; //The maximum legal value for cheese
		
		if ((cheese >= minCheese) && (cheese <= maxCheese)){
			this.cheese = cheese; 
		} else {
			throw new IllegalPizza("The amount of cheese you entered is invalid.");
		}
		
	}
	
	/* This method will set the number of ham to the attribute */
	private void setHam(int ham) throws IllegalPizza {
		
		int minHam = 0; //The minimum legal value for ham
		int maxHam = 3; //The maximum legal value for ham
		
		if ((ham >= minHam) && (ham <= maxHam)){
			this.ham = ham;
		} else {
			throw new IllegalPizza("The amount of ham you entered is invalid.");
		}
		/* This if statement will check if the new combination ham/pepperoni is legal */
		if (pepperoni != null)
			setPepperoni(pepperoni);
		
	}
	
	/* This method will set the number of pepperoni to the attribute *
	 * and will check that the total of ham and pepperoni does not	 *
	 * go beyond 3													 */
	private void setPepperoni(int pepperoni) throws IllegalPizza {
		
		int minPepperoni = 0; //The minimum legal value for Pepperoni
		int maxPepperoni = 3; //The maximum legal value for Pepperoni
		int maxPeppHam = 3; //The maximum legal combination of Ham and Pepperoni
		int combPeppHam = (pepperoni + ham); 
		
		if ((pepperoni > maxPepperoni) || (pepperoni < minPepperoni)){
			throw new IllegalPizza("The amount of pepperoni you entered is invalid.");
		} else if (combPeppHam > maxPeppHam){
			throw new IllegalPizza("Illegal combination of ham and pepperoni");
		} else {
			this.pepperoni = pepperoni;
		}
	}

	/* This method will return the price for the size of the pizza *
	 * (i.e "small" -> 7)										   */
	private int costForSize(){
		
		int smallPrice = 7; //Price for a small pizza
		int mediumPrice = 9; //Price for a medium pizza
		int largePrice = 11; //Price for a large pizza
		
		if (size.equals("small")){
			return smallPrice;
		} else if (size.equals("medium")){
			return mediumPrice;
		} else {
			return largePrice;
		}
	}
	
	/* This method will return the String equivalent of the number *
	 * of toppings (i.e 3 -> "triple") (Notice 0 doesn't appear    *
	 * since the non-existent topping will not get listed.)		   */
	private String numOfTopToStr(int num){
		
		if (num == 1){
			return "single";
		} else if (num == 2) {
			return "double";
		} else {
			return "triple";
		}
	}

	/**
	 * This method overrides the generic clone method
	 * It creates a new Pizza object with all attributes equals to this one
	 * 
	 * @return newPizza The new Pizza object created by cloning this one.
	 */ 
	@Override
	public Pizza clone(){
		
		Pizza newPizza = null;
		try {
			newPizza = new Pizza(size, cheese, ham, pepperoni);
		} catch (IllegalPizza e) {
			System.out.println(e.getMessage());
		}
		return newPizza;
		
	}
	
	/**
	 * This method is the accessor used to get the cost of the Pizza
	 * It calls costForSize() and adds to it the price for extra toppings
	 * 
	 * @return priceOfPizza The price of the pizza
	 */ 
	public double getCost(){
		
		double pricePerTopping = 1.5;
		int extraCheese = cheese - 1; //This variable will be used to exclude the free single cheese from the cost calculation
		double priceOfPizza;
		priceOfPizza = (costForSize() + (pricePerTopping * (extraCheese + ham + pepperoni)));
		
		return priceOfPizza;
	}
	
	/**
	 * This method will return a string describing the pizza
	 * It creates a string containing only the size and portion of cheese
	 * and adds to it the portion of ham and pepperoni depending whether they exist 
	 * 
	 * @return pizzaString The string describing the Pizza
	 */ 
	public String toString(){
		
		String pizzaString;
		pizzaString = size + " pizza, " + numOfTopToStr(cheese) + " cheese";
		if (ham != 0)
			pizzaString = pizzaString + ", " + numOfTopToStr(ham) + " ham";
		if (pepperoni != 0)
			pizzaString = pizzaString + ", " + numOfTopToStr(pepperoni) + " pepperoni";
		pizzaString = pizzaString + ". Cost: $" + getCost() + "0"; //The 0 at the end is added to have 2 decimals in the price (i.e $17.50 instead of $17.5)
		
		return pizzaString;
	}
	
	/**
	 * This method will determine if two Pizza objects are identical
	 * It compares all the attributes of the two Pizza objects
	 * and if all are the same, it returns true otherwise false.
	 * 
	 * @param anotherObject This is the object to be compared to the one holding this method.
	 * @return A boolean, true if the objects are the same, false otherwise.
	 */ 
	public boolean equals(Object anotherObject){
		
		if (anotherObject instanceof Pizza){
			
			Pizza anotherPizza = (Pizza)anotherObject;
			if ((anotherPizza.size.equals(size)) &&
				(anotherPizza.cheese == cheese) &&
				(anotherPizza.ham == ham ) &&
				(anotherPizza.pepperoni == pepperoni)){
					return true;
			} else {
					return false;
			}
			
		} else {
			return false;
		}
	}
	
}
