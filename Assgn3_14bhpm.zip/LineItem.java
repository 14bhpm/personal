import java.io.Serializable;

/**
 * This class contains the LineItem object to complement the PizzaOrderSystem
 * It describes an order of pizza, containing the Pizza object (only a pointer actually) and the number
 * of this pizza the customer desires
 * It has two attributes: - pizza - number -
 * All methods except setPizza are public
 * 
 * @author Beltan Michel - 10169162 - 14bhpm
 * @version 1.0
 */ 

public class LineItem implements Comparable<LineItem>, Serializable {
	
	private static final long serialVersionUID = 0; //This class was not created using Eclipse
	private Pizza pizza;
	private int number;
	
	/**
	 * This is the main constructor for LineItem
	 * It takes both the pizza and the number of it as parameters
	 * and calls the setAttributes methods to set them
	 * 
	 * @param number The number of pizza this LineItem will hold
	 * @param pizza The pizza this LineItem will hold
	 */ 
	public LineItem(int number, Pizza pizza) throws IllegalPizza{
		
		setNumber(number);
		setPizza(pizza);
		
	}
	
	/**
	 * This is the second constructor for LineItem
	 * It is called when only the pizza is specified as parameter
	 * It defaults the number to 1 and calls the setAttributes
	 * 
	 * @param pizza The pizza this LineItem will hold
	 */ 
	public LineItem(Pizza pizza) throws IllegalPizza{
		
		setNumber(1); //The default number of pizzas is 1
		setPizza(pizza);
		
	}
	
	/* This method sets the pointer in this LineItem to the pizza given to it *
	 * It is the only private method since you cannot modify the pizza in the *
	 * LineItem.															  */
	private void setPizza(Pizza pizza){
		
		this.pizza = pizza;
		
	}
	
	/**
	 * This method sets the number Attribute of the object to a specified value
	 * It also verifies that the number is legal (between 1 and 100 inclusive)
	 * 
	 * @param number The number to be set in the number Attribute
	 */ 
	public void setNumber(int number) throws IllegalPizza {
		
		int minNumber = 1; //The lowest legal number of pizzas
		int maxNumber = 100; //The highest legal number of pizzas
		
		if ((number >= minNumber) && (number <= maxNumber)){
			this.number = number;
		} else {
			throw new IllegalPizza("The number of pizzas you entered is invalid.");
		}
	}
	
	/**
	 * This method will return the pointer to the pizza object
	 * 
	 * @return pizza The pointer to the pizza object 
	 */ 
	public Pizza getPizza(){
		
		return pizza;
		
	}
	
	/**
	 * This method will return the number of pizzas this LineItem holds
	 * 
	 * @return number The number of pizzas stored in this LineItem
	 */ 
	public int getNumber(){
		
		return number;
		
	}
	
	/**
	 * This method will return the cost for all the pizzas stored in this LineItem
	 * 
	 * @return totalCost The cost calculated by (number of pizzas)*(price of pizza) 
	 */ 
	public double getCost(){
		
		double costOfPizza = pizza.getCost();
		double totalCost = number * costOfPizza;
		
		return totalCost;
		
	}
	
	/**
	 * This method will return a string will all the information about this LineItem
	 * in the format: (number of pizza) (what's on the pizza) (cost for each pizza)
	 * To get what's on the pizza and the cost for each pizza, it calls pizza.toString()
	 * 
	 * @return itemAsStr The string describing this LineItem
	 */ 
	public String toString(){
		
		String itemAsStr;
		itemAsStr = number + " " + pizza.toString();
		
		return itemAsStr;
	}
	
	/**
	 * This method will compare two LineItem objects on the basis of total price
	 * If this object's total price is bigger, the returned value is positive
	 * If the other object's total price is bigger, the returned value is negate
	 * If the difference between the two is less than 1 or -1, the returned value is 0
	 * 
	 * @param anotherLI This is the other LineItem object to be compared to this one
	 * @return difference The value telling which is bigger
	 */ 
	public int compareTo(LineItem anotherLI){
		
		int difference = (int)(getCost() - anotherLI.getCost());
		return difference;
		
	}
	
}
