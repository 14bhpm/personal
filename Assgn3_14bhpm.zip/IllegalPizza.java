/** This class is the Exception class for the Pizza and LineItem classes.
 * It prints an error message to the screen in case of illegality 
 * The cases for illegality are:
 * Object Pizza:		
 * 		- size is not "small" | "medium" | "large"				  
 * 		- cheese not between 1 and 3					  
 * 		- ham and/or pepperoni not between 0 and 3		  
 * 		- Sum of ham and pepperoni above 3	
 * Object LineItem:
 * 		- number of Pizzas not between 1 and 100
 * 
 * @author Beltan Michel - 10169162 - 14bhpm
 * @version 1.0			
 */   

public class IllegalPizza extends Exception{
	
	/**
	 * This constructor will display a specified error message
	 * 
	 * @param message The error message to be displayed
	 */ 
	public IllegalPizza(String message){
		super(message);
	}
	
}
