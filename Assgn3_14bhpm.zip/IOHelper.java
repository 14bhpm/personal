import java.util.Scanner;

/**
 * This is the IOHelper class used to get input from the user
 * It contains two main methods: getInt that returns an integer
 * and getString that returns a String.
 * getInt is overloaded to allow up to 3 parameters, starting from 0
 * 
 * @author Beltan Michel - 10169162 - 14bhpm
 * @version 1.0
 */ 

public class IOHelper{
	
	/**
	 * This method prompts the user for a String input and returns it
	 * It uses the Scanner class to take input from the console
	 * 
	 * @param message The message to be displayed explaining the input
	 * @return userStr The string entered by the user
	 */ 
	public static String getString(String message){
		
		Scanner screen = new Scanner(System.in);
		System.out.println(message);
		String userStr = screen.nextLine();
		
		return userStr;
		
	}
	
	/**
	 * This method is the main getInt method returning an integer entered by the user
	 * It also uses the scanner class and includes two boundaries for the entered integer
	 * If the provided integer is not within the boundaries, it will keep
	 * asking for one until it is within them.
	 * 
	 * @param lowLimit The low boundary for the integer to be entered.
	 * @param highLimit The high boundary for the integer to be entered.
	 * @param message The message displayed explaining what to input.
	 * @return userInt The integer entered by the user.
	 */ 
	public static int getInt(int lowLimit, String message, int highLimit){
		
		int userInt;
		Scanner screen;
		
		do {
			screen = new Scanner(System.in);
			System.out.println(message);
			userInt = screen.nextInt();
			if ((userInt > highLimit) || (userInt < lowLimit))
				System.out.println("Illegal number entered. Please try again");
		} while ((userInt > highLimit) || (userInt < lowLimit));
		
		return userInt;
		
	}
	
	/**
	 * This method is an overload of getInt
	 * It takes only the message and the highLimit, generates
	 * a default value for the lowLimit and then calls the main getInt
	 * 
	 * @param message The message to be displayed explaining what to input
	 * @param highLimit The highest integer the input can be
	 * @return getInt Calls the main getInt method and returns what this one generates
	 */ 
	public static int getInt(String message, int highLimit){
		
		int lowLimit = Integer.MIN_VALUE;
		return getInt(lowLimit, message, highLimit);
		
	}
	
	/**
	 * This method is an overload of getInt
	 * It takes only the message and the lowLimit, generates
	 * a default value for highLimit and then calls the main getInt
	 * 
	 * @param message The message to be displayed explaining what to input
	 * @param lowLimit The lowest integer the input can be
	 * @return getInt Calls the main getInt method and returns what this one generates
	 */ 
	public static int getInt(int lowLimit, String message){
		
		int highLimit = Integer.MAX_VALUE;
		return getInt(lowLimit, message, highLimit);
		
	}
	
	/**
	 * This method is an overload of getInt
	 * It takes only the message to display, generates
	 * a default value for the highLimit and the lowLimit and calls the main getInt
	 * 
	 * @param message The message to be displayed explaining what to input
	 * @return getInt Calls the main getInt method and returns what this one generates
	 */ 
	public static int getInt(String message){
		
		int lowLimit = Integer.MIN_VALUE;
		int highLimit = Integer.MAX_VALUE;
		return getInt(lowLimit, message, highLimit);
		
	}
	
	/**
	 * This method is an overload of getInt
	 * It takes no parameter, generates a basic message, the lowLimit
	 * and the highLimit and then calls the main getInt
	 * 
	 * @return getInt Calls the main getInt method and returns what this one generates
	 */ 
	public static int getInt(){
		
		int lowLimit = Integer.MIN_VALUE;
		int highLimit = Integer.MAX_VALUE;
		String message = "Please enter a number :";
		return getInt(lowLimit, message, highLimit);
		
	}
	
}
